function varargout = SuperResolutionGUI(varargin)
% SUPERRESOLUTIONGUI MATLAB code for SuperResolutionGUI.fig
%      SUPERRESOLUTIONGUI, by itself, creates a new SUPERRESOLUTIONGUI or raises the existing
%      singleton*.
%
%      H = SUPERRESOLUTIONGUI returns the handle to a new SUPERRESOLUTIONGUI or the handle to
%      the existing singleton*.
%
%      SUPERRESOLUTIONGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SUPERRESOLUTIONGUI.M with the given input arguments.
%
%      SUPERRESOLUTIONGUI('Property','Value',...) creates a new SUPERRESOLUTIONGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SuperResolutionGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SuperResolutionGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SuperResolutionGUI

% Last Modified by GUIDE v2.5 31-Mar-2017 15:15:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SuperResolutionGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @SuperResolutionGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SuperResolutionGUI is made visible.
function SuperResolutionGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SuperResolutionGUI (see VARARGIN)

% Choose default command line output for SuperResolutionGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SuperResolutionGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SuperResolutionGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in button2x.
function button2x_Callback(hObject, eventdata, handles)
% hObject    handle to button2x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of button2x


% --- Executes on button press in button4x.
function button4x_Callback(hObject, eventdata, handles)
% hObject    handle to button4x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of button4x


% --- Executes on button press in button8x.
function button8x_Callback(hObject, eventdata, handles)
% hObject    handle to button8x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of button8x


% --- Executes on button press in button16x.
function button16x_Callback(hObject, eventdata, handles)
% hObject    handle to button16x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of button16x

% --- Executes on button press in inputImageButton.
function inputImageButton_Callback(hObject, eventdata, handles)
% hObject    handle to inputImageButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fileName, dirName] = uigetfile();
hObject.UserData = [dirName, fileName];
hObject.String = 'Image uploaded!';


function HR_ratio_Box_Callback(hObject, eventdata, handles)
% hObject    handle to HR_ratio_Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HR_ratio_Box as text
%        str2double(get(hObject,'String')) returns contents of HR_ratio_Box as a double

hObject.UserData = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function HR_ratio_Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HR_ratio_Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in libraryImgButton.
function libraryImgButton_Callback(hObject, eventdata, handles)
% hObject    handle to libraryImgButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fileName, dirName] = uigetfile();
hObject.UserData = [dirName, fileName];


% --- Executes on button press in libraryPatchButton.
function libraryPatchButton_Callback(hObject, eventdata, handles)
% hObject    handle to libraryPatchButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fileName, dirName] = uigetfile();
hObject.UserData = [dirName, fileName];

% --- Executes on button press in resetButton.
function resetButton_Callback(hObject, eventdata, handles)
% hObject    handle to resetButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.cancelButton, 'visible', 'off');
set(handles.statusText, 'visible', 'off');
set(handles.downloadButton, 'visible', 'off');


% --- Executes on button press in reconstructionButton.
function reconstructionButton_Callback(hObject, eventdata, handles)
% hObject    handle to reconstructionButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

image_handle = findobj('Tag', 'inputImageButton');
image_name = image_handle.UserData;

NLM_handle = findobj('Tag', 'NLM_RadioButton');
BM3D_handle = findobj('Tag', 'BM3D_RadioButton');
KSVD_handle = findobj('Tag', 'KSVD_RadioButton');
qGGMRF_handle = findobj('Tag', 'qGGMRF_RadioButton');

if get(NLM_handle, 'Value') == 1
    prior = 10;
    maxIter = 10;
    regularization_handle = findobj('Tag', 'NLMbetaBox');
    patchSize_handle = findobj('Tag', 'NLM_patchSizeBox');
    regularization = regularization_handle.Value;
    patchSize = patchSize_handle.Value;
    
    HRlib_CheckBox_handle = findobj('Tag', 'HRlib_CheckBox');
    if HRlib_CheckBox_handle.Value == 1
        library_image_handle = findobj('Tag', 'libraryImgButton');
        library_image_name = library_image_handle.UserData;
        libSize_handle = findobj('Tag', 'HR_ratio_Box');
        libSize = libSize_handle.UserData;
        libPatch_handle = findobj('Tag', 'libraryPatchButton');
        lib_patch_name = libPatch_handle.UserData;
    else
        library_image_name = image_name;
        libSize = 40; % As a percentage
    end
    
elseif get(BM3D_handle, 'Value') == 1
    prior = 1;
    maxIter = 90;
    regularization_handle = findobj('Tag', 'BM3DbetaBox');
    regularization = regularization_handle.Value;
elseif get(KSVD_handle, 'Value') == 1
    prior = 0;
    maxIter = 40;
    regularization_handle = findobj('Tag', 'KSVDbetaBox');
    regularization = regularization_handle.Value;
elseif get(qGGMRF_handle, 'Value') == 1
    prior = 4;
    maxIter = 75;
    regularization_handle = findobj('Tag', 'qGGMRFbetaBox');
    regularization = regularization_handle.Value;
end

if size(regularization, 1) == 0 || regularization == 0
    regularization = 1.0;
end

if size(patchSize, 1) == 0 || patchSize == 0
    patchSize = 15;
end

if size(libSize, 1) == 0 || libSize == 0
    libSize = 50;
end

handle2x = findobj('Tag', 'button2x');
handle4x = findobj('Tag', 'button4x');
handle8x = findobj('Tag', 'button8x');
handle16x = findobj('Tag', 'button16x');

if get(handle2x, 'Value') == 1
    factor = 2;
elseif get(handle4x, 'Value') == 1
    factor = 4;
elseif get(handle8x, 'Value') == 1
    factor = 8;
elseif get(handle16x, 'Value') == 1
    factor = 16;
end

maxIter_handle = findobj('Tag', 'maxIterTextBox');
if maxIter_handle.UserData
    maxIter = maxIter_handle.UserData;
end

sigmaLambda_handle = findobj('Tag', 'sigmaLambdaTextBox');
if sigmaLambda_handle.UserData
    sigmaLambda = sigmaLambda_handle.UserData;
end

initializationMethod = 1; % default: 1 (cubic interpolation)
initialEst = []; % default: blank file
initialEst_handle = findobj('Tag', 'initialImgButton');
if initialEst_handle.UserData
    initialEst = imread(initialEst_handle.UserData);
    initializationMethod = 2; % for loading your own initialization
end

cancelButton_handle = findobj('Tag', 'cancelButton');
cancelButton_handle.Visible = 'on';

x = SR_function(image_name, factor, library_image_name, libSize, prior, maxIter, initializationMethod, regularization, patchSize, initialEst);

figure
subplot(1, 2, 1)
imshow(imread(image_name));
title('Low-res input');
subplot(1, 2, 2)
imshow(uint8(x));
titleLine = sprintf('%d x super-res output', factor);
title(titleLine);

statusText_handle = findobj('Tag', 'statusText');
statusText_handle.Visible = 'on';
downloadButton_handle = findobj('Tag', 'downloadButton');
downloadButton_handle.Visible = 'on';


% --- Executes on button press in cancelButton.
function cancelButton_Callback(hObject, eventdata, handles)
% hObject    handle to cancelButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on HR_ratio_Box and none of its controls.
function HR_ratio_Box_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to HR_ratio_Box (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in downloadButton.
function downloadButton_Callback(hObject, eventdata, handles)
% hObject    handle to downloadButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function pValueBox_Callback(hObject, eventdata, handles)
% hObject    handle to pValueBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pValueBox as text
%        str2double(get(hObject,'String')) returns contents of pValueBox as a double

hObject.UserData = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function pValueBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pValueBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qValueBox_Callback(hObject, eventdata, handles)
% hObject    handle to qValueBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qValueBox as text
%        str2double(get(hObject,'String')) returns contents of qValueBox as a double

hObject.UserData = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function qValueBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qValueBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function NLMbetaBox_Callback(hObject, eventdata, handles)
% hObject    handle to NLMbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NLMbetaBox as text
%        str2double(get(hObject,'String')) returns contents of NLMbetaBox as a double

hObject.Value = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function NLMbetaBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NLMbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NLM_patchSizeBox_Callback(hObject, eventdata, handles)
% hObject    handle to NLM_patchSizeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NLM_patchSizeBox as text
%        str2double(get(hObject,'String')) returns contents of NLM_patchSizeBox as a double

hObject.Value = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function NLM_patchSizeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NLM_patchSizeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BM3DbetaBox_Callback(hObject, eventdata, handles)
% hObject    handle to BM3DbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BM3DbetaBox as text
%        str2double(get(hObject,'String')) returns contents of BM3DbetaBox as a double

hObject.Value = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function BM3DbetaBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BM3DbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function KSVDbetaBox_Callback(hObject, eventdata, handles)
% hObject    handle to KSVDbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KSVDbetaBox as text
%        str2double(get(hObject,'String')) returns contents of KSVDbetaBox as a double

hObject.Value = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function KSVDbetaBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KSVDbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qGGMRFbetaBox_Callback(hObject, eventdata, handles)
% hObject    handle to qGGMRFbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qGGMRFbetaBox as text
%        str2double(get(hObject,'String')) returns contents of qGGMRFbetaBox as a double

hObject.Value = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function qGGMRFbetaBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qGGMRFbetaBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on NLMbetaBox and none of its controls.
function NLMbetaBox_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to NLMbetaBox (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in NLM_RadioBotton.
function NLM_RadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to NLM_RadioBotton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of NLM_RadioBotton


% --- Executes on button press in BM3D_RadioButton.
function BM3D_RadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to BM3D_RadioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of BM3D_RadioButton


% --- Executes on button press in KSVD_RadioButton.
function KSVD_RadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to KSVD_RadioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of KSVD_RadioButton


% --- Executes on button press in qGGMRF_RadioButton.
function qGGMRF_RadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to qGGMRF_RadioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of qGGMRF_RadioButton


% --- Executes on button press in HRlib_CheckBox.
function HRlib_CheckBox_Callback(hObject, eventdata, handles)
% hObject    handle to HRlib_CheckBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of HRlib_CheckBox

HRlib_handle = findobj('Tag', 'HRlib_buttonGroup');

if get(hObject, 'Value') == 1
    HRlib_handle.Visible = 'on';
else
    HRlib_handle.Visible = 'off';
end


% --- Executes during object creation, after setting all properties.
function HRlib_buttonGroup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HRlib_buttonGroup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function maxIterTextBox_Callback(hObject, eventdata, handles)
% hObject    handle to maxIterTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxIterTextBox as text
%        str2double(get(hObject,'String')) returns contents of maxIterTextBox as a double

hObject.UserData = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function maxIterTextBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxIterTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sigmaLambdaTextBox_Callback(hObject, eventdata, handles)
% hObject    handle to sigmaLambdaTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sigmaLambdaTextBox as text
%        str2double(get(hObject,'String')) returns contents of sigmaLambdaTextBox as a double

hObject.UserData = str2double(get(hObject, 'String'));


% --- Executes during object creation, after setting all properties.
function sigmaLambdaTextBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sigmaLambdaTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in initialImgButton.
function initialImgButton_Callback(hObject, eventdata, handles)
% hObject    handle to initialImgButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[fileName, dirName] = uigetfile();
hObject.UserData = [dirName, fileName];

