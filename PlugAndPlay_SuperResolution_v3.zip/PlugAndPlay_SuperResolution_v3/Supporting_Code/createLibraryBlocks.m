function libraryPatch = createLibraryBlocks(img, patchSize, K)

block_size = 20;

B = block_size*block_size; % number of pixels in a block
[h, w] = size(img);
side = (patchSize - 1)/2;
img = padarray(img, [side, side], 'replicate');

% Note: K is the desired # of pixels in the library
NB = ceil(K/B); % # of blocks to use in the library
H = h - mod(h, block_size);
W = w - mod(w, block_size);
I = H/block_size;
J = W/block_size;
N = I*J;
blockIndices = randi(N, [1, NB]);

libraryPatch = zeros(patchSize, patchSize, K);
counter = 1;

if (h > block_size) && (w > block_size)
    for b = 1:NB
        q = blockIndices(b);
        i_start = block_size*floor((q-1)/J) + 1 + side; % starting row index of block q
        j_start = block_size*mod(q-1, J) + 1 + side; % starting column index of block q
        for ii = i_start:i_start+block_size-1
            for jj = j_start:j_start+block_size-1
                libraryPatch(:, :, counter) = img(ii-side:ii+side, jj-side:jj+side);
                if counter >= K
                    return
                else
                    counter = counter + 1;
                end
            end
        end
    end
else
    error('Library image too small.');
end



