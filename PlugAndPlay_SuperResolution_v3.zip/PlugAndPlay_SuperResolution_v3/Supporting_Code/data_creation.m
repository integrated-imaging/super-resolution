function [Object, sino, geom, Amatrix] = data_creation(img, mask, sampled, InitialEst)


% InPainting data creation (Code by Suhas Sreehari, May 2015)
% -------------------------------------------------------------------------

% Input and parameters:

% Object = double(imread(image_name)); % [0, 255] scale

Object = InitialEst; % (since there is no ground truth available)

% percentage_fill = sampling; % fill percentage; default: 40
%sino.var_w = 100; % noise variance -- on a [0, 255] scale; default: 100
sino.var_w = 0;

% -------------------------------------------------------------------------

sino.counts = sampled;
[h, w] = size(Object);
geom.n_x = h;
geom.n_y = w;

Amatrix = GenSamplingMask(mask, 0);

clearvars -except Object geom sino Amatrix mask
