
% Library-Bssed Non-Local Means (LB-NLM) Denoiser
% Code author: Suhas Sreehari, Purdue University - West Lafayette, IN, USA.


function [x, weight] = LBNLM(img, libraryPatch, std, strength, patchSize, weightInput)

display = 0;

if nargin == 2
    std = 0;
    patchSize = 5;
    strength = 10;
    calculateWeight = 1;
elseif nargin == 3
    strength = 10;
    patchSize = 5;
    calculateWeight = 1;
elseif nargin == 4
    patchSize = 5;
    calculateWeight = 1;
elseif nargin == 5
    calculateWeight = 1;
elseif nargin == 6
    weight = weightInput;
    calculateWeight = 0;
end

if std == 0
    noisy = img;
else
    noisy = imnoise(img, 'gaussian', 0, (std/255)^2);
end

side = (patchSize-1)/2;
halfSize = side + 1;

[~, ~, K] = size(libraryPatch);

libraryPixels = zeros(1, K);
libraryPixels(:) = libraryPatch(halfSize, halfSize, :);

weightVector = zeros(K, 1);

noisy = double(noisy);
noisy = padarray(noisy, [side, side], 'replicate');

[h, w] = size(noisy);

h_parameter = sqrt(2)*std2(noisy)/strength; % Higher the T, the less denoised the output will be.
h2 = h_parameter^2;

x = noisy; % initialization of the denoised image

if calculateWeight == 1
    weight = zeros(h, w, K); % weight matrix
    for i = 1+side:h-side
        for j = 1+side:w-side
            patch = noisy(i-side:i+side, j-side:j+side);
            
            for k = 1:K
                neighborhood_distance = norm(double(patch - libraryPatch(:, :, k)), 'fro');
                weight(i, j, k) = exp(-neighborhood_distance/h2);
            end
            
            z = sum(weight(i, j, :)); % weight normalization
            weight(i, j, :) = weight(i, j, :)/z;
        end
    end
end


for i = 1:h
    for j = 1:w
        weightVector(:) = weight(i, j, :);
        x(i, j) = libraryPixels*weightVector;
    end
end

x = x(1+side:h-side, 1+side:w-side);

if display == 1
    figure(1)
    subplot(1, 2, 1)
    imshow(uint8(x));
    title('Denoised');
    subplot(1, 2, 2)
    imshow(uint8(noisy(1+side:h-side, 1+side:w-side)));
    title('Noisy');
    
    rmse_NLM = rmse(img, x);
    
    name = sprintf('x_%.4f.tif', rmse_NLM);
    imwrite(x, name);
end

end