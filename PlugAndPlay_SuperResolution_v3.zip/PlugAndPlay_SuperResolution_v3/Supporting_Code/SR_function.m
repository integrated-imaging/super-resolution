function x = SR_function(image_name, factor, library_image_name, libSize, prior, maxIter, initializationMethod, regularization, patchSize, initialEst)

%% Defaults:

if size(initialEst, 1) == 0
    initialEst = [];
end

if size(factor, 1) == 0
    factor = 2;
end

if size(library_image_name, 1) == 0
    library_image_name = image_name;
end

if size(libSize, 1) == 0
    libSize = 10;
end

if size(patchSize, 1) == 0
    patchSize = 9;
end

if size(prior, 1) == 0
    prior = 1;
end

%% Code

output_folder_name = 'Results';


% initializationMethod -> 0: Shepard, 1: Cubic, 2: use your own initialization

img = double(imread(image_name));
[h, w] = size(img);


HR_img = double(imread(library_image_name)); % High-Resolution image
HR_img = HR_img/max(HR_img(:));
[h_lib, w_lib] = size(HR_img);
HR_img = 255*HR_img;

NL1 = 0;
NL2 = (double(libSize)/10.0)*h_lib*w_lib; % Default: 5000

if NL1 > h*w
    NL1 = h*w;
end

if NL2 > h_lib*w_lib
    NL2 = h_lib*w_lib;
end

library1 = createLibrary(img, patchSize, NL1);
library2 = createLibrary(HR_img, patchSize, NL2);

library = zeros(patchSize, patchSize, NL1+NL2);
library(:, :, 1:NL1) = library1(:, :, :);
library(:, :, NL1+1:NL1+NL2) = library2(:, :, :);

mask = zeros(factor*h, factor*w);
mask(1:factor:factor*h, 1:factor:factor*w) = 1;
sampled = zeros(factor*h, factor*w);
sampled(1:factor:factor*h, 1:factor:factor*w) = img(1:h, 1:w);

if (initializationMethod == 0) % Shepard's interpolation
    InitialEst = shepard_initialize(sampled, mask, 21, 2);
    InitialEst = InitialEst(1:factor*h, 1:factor*w);
    InitialEst(1:factor:factor*h, 1:factor:factor*w) = img(1:h, 1:w);
elseif (initializationMethod == 1) % Cubic interpolation
    InitialEst = cubicInterpolate(img, factor);
elseif (initializationMethod == 2) % Load your own initialization
    InitialEst = initialEst;
end

[x, ~, ~, ~] = PlugAndPlayPriorFunction(image_name, output_folder_name, factor, prior, maxIter, regularization, InitialEst, mask, sampled, library, patchSize, factor, HR_img);
