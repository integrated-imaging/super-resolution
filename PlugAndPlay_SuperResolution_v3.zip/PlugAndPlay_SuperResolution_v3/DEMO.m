clc
close all

addpath(genpath('../PlugAndPlay_SuperResolution'))

%% Inputs and Options

image_name = 'Images/Gold_atoms/Gold_atoms_LR8x.png';
library_image_name = 'Images/Gold_atoms/Gold_atoms.tif';
R = 8; % super-resolution factor

prior = 10; % 0: K-SVD, 1: BM3D, 9: NLM, 10: LB-NLM
beta = 1.2;

% LB-NLM parameters:
patchSize = 21; % patch size for NLM-based methods; default: 9
NL = 3000; % # of high-res measurements to be used in the library patches

initializationMethod = 1;  % 1: Cubic, 2: load your own initialization
output_folder_name = 'Results';


%% Code

img = double(imread(image_name));
[h, w] = size(img);

HR_img = double(imread(library_image_name)); % High-Resolution image
HR_img = HR_img/max(HR_img(:));
HR_img = 255*HR_img;

library = createLibrary(HR_img, patchSize, NL); % creates a stack of library patches

%library = createLibraryBlocks(HR_img, patchSize, NL); % This also creates a stack of library aptches; Use this for
%randomly picking blocks from a large library image -- to create the
%library patches

mask = zeros(R*h, R*w);
mask(1:R:R*h, 1:R:R*w) = 1;
sampled = zeros(R*h, R*w);
sampled(1:R:R*h, 1:R:R*w) = img(1:h, 1:w);

if (initializationMethod == 1) % Cubic interpolation
    InitialEst = cubicInterpolate(img, R);
elseif (initializationMethod == 2) % Load your own initialization
    % InitialEst = double(imread('filename.extension'));
end

[map_image, params, primal_residue, dual_residue] = PlugAndPlayPriorFunction(img, output_folder_name, R, prior, beta, InitialEst, mask, sampled, library, patchSize, R, HR_img);

